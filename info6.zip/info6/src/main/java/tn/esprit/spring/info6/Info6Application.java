package tn.esprit.spring.info6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Info6Application {

    public static void main(String[] args) {
        SpringApplication.run(Info6Application.class, args);
    }

}
