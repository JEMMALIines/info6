package tn.esprit.spring.info6.controllers;
import tn.esprit.spring.info6.entities.Equipe;
import tn.esprit.spring.info6.interfces.EquipeService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/equipes")
@AllArgsConstructor
@RestController
public class EquipeController {
    EquipeService equipeService;
    @GetMapping("/get-all")
    public List<Equipe> retrieveAllEquipes() {
        return equipeService.retrieveAllEquipes();    }
    @PostMapping("/add-equipe")
    Equipe addEquipe(@RequestBody Equipe e) {
        return equipeService.addEquipe(e);    }
    @PutMapping("/update-equipe")
    Equipe updateEquipe(@RequestBody Equipe e) {
        return equipeService.updateEquipe(e);    }
    @GetMapping("/retrieve-equipe/{id}")
    Equipe retrieveEquipe(@PathVariable("id") Integer idEquipe) {
        return equipeService.retrieveEquipe(idEquipe);    }
}
