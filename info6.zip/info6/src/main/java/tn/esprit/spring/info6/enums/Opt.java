package tn.esprit.spring.info6.enums;

public enum Opt {
}
