package tn.esprit.spring.info6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Info6ApplicationTests {

    @Test
    void contextLoads() {
    }

}
